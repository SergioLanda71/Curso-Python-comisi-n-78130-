# Segunda Entrega — Reestructuración en Paquetes

## Estructura
- `ecommerce_app/domain` (clases)
- `ecommerce_app/infrastructure` (repositorios)
- `ecommerce_app/cli.py` (entrypoint)
- `tests/` (pytest)
- `Ejecutar.py` (demo simple)

## Ejecutar
```bash
python3 Ejecutar.py
# o
python3 -m ecommerce_app.cli
```

## Tests
```bash
pip install pytest
pytest -q
```
