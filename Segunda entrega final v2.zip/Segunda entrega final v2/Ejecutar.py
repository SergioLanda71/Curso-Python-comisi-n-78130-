from ecommerce_app.domain.models import Cliente, ClientePremium
from ecommerce_app.infrastructure.repository import InMemoryClienteRepository

def main():
    repo = InMemoryClienteRepository()
    c1 = Cliente(1, "Ana", "ana@gmail.com", "Calle 123", saldo=300)
    c2 = ClientePremium(2, "Luis", "luis@gmail.com", "Av Siempre Viva 742", saldo=300)
    repo.add(c1); repo.add(c2)
    c1.comprar(100); c2.comprar(100)
    repo.update(c1); repo.update(c2)
    for c in repo.all(): print(" -", c)

if __name__ == "__main__":
    main()
