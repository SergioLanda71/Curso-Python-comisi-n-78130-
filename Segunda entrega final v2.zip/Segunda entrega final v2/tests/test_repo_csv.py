from ecommerce_app.domain.models import Cliente
from ecommerce_app.infrastructure.repository import CSVClienteRepository

def test_repo_csv_crud(tmp_path):
    f = tmp_path / "clientes.csv"
    r = CSVClienteRepository(f)
    c = Cliente(1, "Ana", "ana@gmail.com", "Calle", saldo=100)
    r.add(c); assert r.get(1) is not None
    c.recargar_saldo(30); r.update(c); assert r.get(1).saldo == 130
    assert len(list(r.all())) == 1
    r.remove(1); assert r.get(1) is None
