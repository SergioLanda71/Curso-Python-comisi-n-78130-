# 📌 NOTA PARA LA CORRECCIÓN
import sys
from ecommerce_app.domain.models import Cliente, ClientePremium
from ecommerce_app.infrastructure.repository import (
    InMemoryClienteRepository, JSONClienteRepository, CSVClienteRepository
)

def main() -> None:
    """
    CLI:
      - add <id> <nombre> <email> <direccion> [saldo]
      - list
      - buy <id> <monto> [premium]
      - topup <id> <monto>
    """
    repo = InMemoryClienteRepository()

    if len(sys.argv) < 2:
        print(main.__doc__); raise SystemExit(0)

    cmd, *args = sys.argv[1:]

    if cmd == "add":
        if len(args) < 4:
            print("Uso: add <id> <nombre> <email> <direccion> [saldo]"); raise SystemExit(1)
        id_cliente = int(args[0]); nombre, email, direccion = args[1:4]
        saldo = float(args[4]) if len(args) > 4 else 0.0
        c = Cliente(id_cliente, nombre, email, direccion, saldo=saldo)
        repo.add(c); print("OK:", c)

    elif cmd == "list":
        for c in repo.all(): print(c)

    elif cmd == "buy":
        if len(args) < 2:
            print("Uso: buy <id> <monto> [premium]"); raise SystemExit(1)
        id_cliente = int(args[0]); monto = float(args[1])
        premium = (len(args) > 2 and args[2].lower() == "premium")
        c = repo.get(id_cliente)
        if c is None:
            c = (ClientePremium if premium else Cliente)(id_cliente, "Demo", "demo@gmail.com", "Calle 123", saldo=1000.0)
            repo.add(c)
        c.comprar(monto); repo.update(c); print("Compra OK:", c)

    elif cmd == "topup":
        if len(args) < 2:
            print("Uso: topup <id> <monto>"); raise SystemExit(1)
        id_cliente = int(args[0]); monto = float(args[1])
        c = repo.get(id_cliente)
        if c is None:
            c = Cliente(id_cliente, "Demo", "demo@gmail.com", "Calle 123", saldo=0.0)
            repo.add(c)
        c.recargar_saldo(monto); repo.update(c); print("Recarga OK:", c)

    else:
        print("Comando desconocido."); print(main.__doc__)

if __name__ == "__main__":
    main()
